﻿using UnityEngine;
using System.Collections;

public class rotar : MonoBehaviour {

    private bool rotasao = false;
    public Transform final;
    public Transform inicio;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        Debug.DrawLine(inicio.position, final.position,Color.blue);
        if(Input.GetKeyDown(KeyCode.D))
        {
            transform.Rotate(0,180,0);
            //rotasao = true;
        }
        //rotasao = false;
	}
}
