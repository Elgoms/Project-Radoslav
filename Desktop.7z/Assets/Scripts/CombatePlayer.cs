﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatePlayer : MonoBehaviour {
    public int maxHP;

    public int currentHP
    {
        get
        {
            return currentHP;
        }
        set{
            currentHP = value;
        }
    }
    
}

   